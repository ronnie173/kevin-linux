This directory contains benchmark code one can use to measure/verify
various aspects of VTD-XML performance claim.

./memory contains the memory usage measuring code

./performance_navigation contains the code measuring navigation performance

./performance_parsing contains the code measuring parsing performance

./roundTrip contains the code measuring the baseline performance of parsing/reserialization

./update contains the code measuring the combination of parsing/XPath evaluation/output serialization.

./xpath contains the code measuring xpath evaluation performance

./indexing contains the code measuring indexing performance

./xml contains various xml documents used for benchmarking
