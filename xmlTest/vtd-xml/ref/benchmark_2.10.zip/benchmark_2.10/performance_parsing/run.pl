my @small_files = ("soap2.xml","nav_48_0.xml","cd_catalog.xml","nav_63_0.xml",
	"soap_small.xml","book.xml","form.xml","OfficeOrder.xml");
my @medium_files = ("bioinfo.xml","soap_mid.xml","cd.xml","po1m.xml","blog.xml");
my @big_files = ("soap.xml","bioinfo_big.xml","ORTCA.xml","SUAS.xml","address.xml",
	"cd_big.xml","po.xml");
@abc = (1,2,3);

print "******************\n\n";
for ($i=0;$i<=$#small_files;$i++){
	my $file_name =  $small_files[$i];
	print "file_name ==> $file_name\n\n";
	print "===C#===\n";
	system("benchmark_parsing.exe d:\\xmls\\$file_name");
	print "===C===\n";
	system("benchmark_vtdxml.exe d:\\xmls\\$file_name");
	print "===Java Server JVM===\n";
	system("java -server -Xmx300m benchmark_BR d:\\xmls\\$file_name");
	print "===Java client JVM===\n";
	system("java -client -Xmx300m benchmark_BR d:\\xmls\\$file_name");
}
print "******************\n\n";
for ($i=0;$i<=$#medium_files;$i++){
	my $file_name =  $medium_files[$i];
	print "file_name ==> $file_name\n\n";
	print "===C#===\n";
	system("benchmark_parsing.exe d:\\xmls\\$file_name");
	print "===C===\n";
	system("benchmark_vtdxml.exe d:\\xmls\\$file_name");
	print "===Java Server JVM===\n";
	system("java -server -Xmx300m benchmark_BR d:\\xmls\\$file_name");
	print "===Java client JVM===\n";
	system("java -client -Xmx300m benchmark_BR d:\\xmls\\$file_name");
}

print "******************\n\n";
for ($i=0;$i<=$#big_files;$i++){
	my $file_name =  $big_files[$i];
	print "file_name ==> $file_name\n\n";
	print "===C#===\n";
	system("benchmark_parsing.exe d:\\xmls\\$file_name");
	print "===C===\n";
	system("benchmark_vtdxml.exe d:\\xmls\\$file_name");
	print "===Java Server JVM===\n";
	system("java -server -Xmx300m benchmark_BR d:\\xmls\\$file_name");
	print "===Java client JVM===\n";
	system("java -client -Xmx300m benchmark_BR d:\\xmls\\$file_name");
}
