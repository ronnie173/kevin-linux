import com.ximpleware.*;
import com.ximpleware.xpath.*;
import java.io.*;

public class xpath_vtd3 {
    public static void main(String args[]){
        try{
            int i1=0,k=0, total=200;
	    long l=0,lt=0;
	    String xpe = xp.getXPath(args[0]);
            File f = new File("po_big.xml");
            byte b[] = new byte[(int)f.length()];
            FileInputStream fis = new FileInputStream(f);
            fis.read(b);
            VTDGen vg = new VTDGen();
            XMLModifier xm = new XMLModifier();            
            AutoPilot ap = new AutoPilot();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();            
            ap.selectXPath(xpe);
	    System.out.println("update_vtd3 =>>> "+ ap.getExprString());
            //ap.selectXPath("/purchaseOrder/items/item");
            k=total;
	    VTDNav vn = null;
	    vg.setDoc(b);
	    vg.parse(true);
            vn = vg.getNav();
            ap.bind(vn);
            xm.bind(vn);
	    while(k>0){
		 //   int i=0;
            	while((i1=ap.evalXPath())!=-1){
		//	i++;
            	}
		//System.out.println(" node count ==> "+i);
            	ap.resetXPath();
	    	k--;
	    }

	    for (int j=0;j<10;j++){
	    	l = System.currentTimeMillis();
	    	for(int i = 0;i<total;i++)
	    	{
		    while((i1=ap.evalXPath())!=-1){
		    }
        	    ap.resetXPath();	
	    	}
		long l2 = System.currentTimeMillis();
		lt = lt + (l2 - l);
		//System.out.println("j ==> "+j);
	    }
	    System.out.println(" average XPath latency ==> "+ 
		        ((double)(lt)/total/10) + " ms");
            //System.out.println(baos.toString());
            
        }catch(IOException e){
		System.out.println(" error ==> "+e);
        }catch(Exception e){
		System.out.println(" error ==> "+e);
        }
    }
}
