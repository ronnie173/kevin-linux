public class xp {
   public static String getXPath(String s){
            String xpe = "/*/*/*[position() mod 2 = 0]";
	    //String xpe = "/purchaseOrder/items/item[USPrice<100]";
	    if (s.equals("1")){
		    xpe =  "/purchaseOrder/items/item[USPrice<100]";
	    }else if (s.equals("2")){
		    xpe = "/*/*/*/quantity/text()";    
	    } else if (s.equals("3")){
		    xpe = "//item/comment";    
	    } else if (s.equals("4")){
		    xpe = "//item/comment/../quantity";    
	    } else if (s.equals("5")){
		    xpe = "/*/*/*/*[position() mod 2 = 0]";
	    } else if (s.equals("6")){
		    xpe = "(/*/*/*/*)[position() mod 2 = 0]";
	    } else if (s.equals("7")){
		    xpe = "/purchaseOrder/items/item[USPrice > 100]/comment/text()";
	    } else if (s.equals("8")){
	    }
	    return xpe;
   }
}
