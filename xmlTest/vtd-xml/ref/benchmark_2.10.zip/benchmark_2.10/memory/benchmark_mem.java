import com.ximpleware.*;
import com.ximpleware.parser.*;
import java.io.*;


public class benchmark_mem {
	static Runtime rt;
      public static void main(String[] args){
	
	File f = new File(args[0]);
	//File f1 = new File("c:\\soap.xml");
	long l;
	int t;
	try{
	    FileInputStream fis = new FileInputStream(f);
	    rt = Runtime.getRuntime();
	    long startMem = rt.totalMemory() - rt.freeMemory();
	    byte[] ba = new byte[(int)f.length()];
	    //FileInputStream fis1 = new FileInputStream(f1);
	    //byte[] ba1 = new byte[(int)f1.length()];
	    t=fis.read(ba);
	    //fis1.read(ba1);
	    VTDGen vg = new VTDGen();
	    //vg.setDoc(ba);
	    int fl = (int) f.length();
	    l = System.currentTimeMillis();
	       vg.setDoc(ba);
	       vg.parse(true); 
            long endMem = rt.totalMemory() - rt.freeMemory();
            System.out.println("Memory Use: " + ((float)endMem - startMem)/(1<<20) + " MB.");
	    System.out.println("Multiplying factor: " + ((float) endMem - startMem)/f.length() );
	    
	 
	}
	catch (ParseException e){	
		System.out.println(" Not wellformed -->" +e);
	}
	catch (IOException e){
		System.out.println(" io exception ");
	} 
      }

}
