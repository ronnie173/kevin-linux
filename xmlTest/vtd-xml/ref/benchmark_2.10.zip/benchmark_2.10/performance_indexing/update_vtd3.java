
/* 
 * Copyright (C) 2002-2004 XimpleWare, info@ximpleware.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
import com.ximpleware.*;
import com.ximpleware.xpath.*;
import java.io.*;

public class update_vtd3 {
    public static void main(String args[]){
        try{
            int i1=0,k=0, total=60;
	    long l=0,lt=0;
	      String xpe = "/*/*/*[position() mod 2 = 0]";
	    //String xpe = "/purchaseOrder/items/item[USPrice<100]";
	    if (args[0].equals("1")){
		    xpe =  "/purchaseOrder/items/item[USPrice<100]";
	    }else if (args[0].equals("2")){
		    xpe = "/*/*/*/quantity/text()";    
	    } else if (args[0].equals("3")){
		    xpe = "//item/comment";    
	    } else if (args[0].equals("4")){
		    xpe = "//item/comment/../quantity";    
	    }  
            File f = new File("po_big.vxl");
            byte b[] = new byte[(int)f.length()];
            FileInputStream fis = new FileInputStream(f);
            fis.read(b);
            VTDGen vg = new VTDGen();
            XMLModifier xm = new XMLModifier();            
            AutoPilot ap = new AutoPilot();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();            
            ap.selectXPath(xpe);
	    System.out.println("update_vtd3 =>>> "+ ap.getExprString());
            //ap.selectXPath("/purchaseOrder/items/item");
            k=total;
	    VTDNav vn = null;
	    while(k>0){
          	vn = vg.loadIndex(b);
           	ap.bind(vn);
            	xm.bind(vn);
            	while((i1=ap.evalXPath())!=-1){
                	xm.remove();                      
            	}
            	xm.output(baos);
            	ap.resetXPath();
            	xm.reset();
		baos.reset();
	    	k--;
	    }

	    for (int j=0;j<10;j++){
	    	l = System.currentTimeMillis();
	    	for(int i = 0;i<total;i++)
	    	{
		 
          	    vn = vg.loadIndex(b);
		    ap.bind(vn);
	    	    xm.bind(vn);
		    while((i1=ap.evalXPath())!=-1){
        	        xm.remove();                      	
		    }
	            xm.output(baos);
        	    ap.resetXPath();	
		    xm.reset();
		    baos.reset();
	    	}
		long l2 = System.currentTimeMillis();
		lt = lt + (l2 - l);
		//System.out.println("j ==> "+j);
	    } 
	    System.out.println(" average combined latency ==> "+ 
		        ((double)(lt)/total/10) + " ms");
            //System.out.println(baos.toString());
            
        }catch(IOException e){
		System.out.println(" error ==> "+e);
        }catch(Exception e){
		System.out.println(" error ==> "+e);
        }
        
    }

}

