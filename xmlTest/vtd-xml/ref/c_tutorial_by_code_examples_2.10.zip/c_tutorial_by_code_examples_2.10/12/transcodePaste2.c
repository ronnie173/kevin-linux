#include "everything.h"

//use thread local storage
_thread struct exception_context the_exception_context[1];
#if 1

int main(){

	exception e;
	VTDGen *vg = NULL; // This is the VTDGen that parses XML
	VTDNav *vn = NULL, *vn2=NULL; // This is the VTDNav that navigates the VTD records
	//AutoPilot *ap = NULL;
	XMLModifier *xm = NULL;
	UByte *ba1 = NULL, *ba2=NULL;
	ElementFragmentNs *efs = NULL;
	int result;
	Long l;
	Try{
		vg = createVTDGen();
		// test2.xml is encoded in UTF-16LE
		if (parseFile(vg,TRUE,"D:/vtd-xml-tutorials/c_tutorial_by_code_examples_2.3/12/test2.xml")==FALSE){
			// parsing failed
			free(vg->XMLDoc);
			freeVTDGen(vg);
			return;
		}
		//parse(vg,TRUE);
		vn = getNav(vg);	
		ba1 =vn->XMLDoc;
		efs = getElementFragmentNs(vn);

		if (parseFile(vg,TRUE,"D:/vtd-xml-tutorials/c_tutorial_by_code_examples_2.3/12/test.xml")==FALSE){
			// parsing failed
			free(ba1);
			freeVTDNav(vn);
			free(vg->XMLDoc);
			freeVTDGen(vg);
			return;
		}
		vn2 = getNav(vg);
		xm = createXMLModifier2(vn2);
		toElement(vn2, FIRST_CHILD);
		insertAfterElement4(xm,efs);
		insertBeforeElement4(xm,efs);
		output2(xm,"D:/vtd-xml-tutorials/c_tutorial_by_code_examples_2.3/12/output.xml");
		
		free(vn2->XMLDoc);
		free(ba1);
		freeVTDNav(vn2);
		freeXMLModifier(xm);
		freeElementFragmentNs(efs);
		free(vn);
		//freeAutoPilot(ap);
		freeVTDGen(vg);

	}
	Catch (e) {
		if (e.et == parse_exception)
			wprintf(L"parse exception e ==> %s \n %s\n", e.msg, e.sub_msg);	
		// manual garbage collection here
		freeVTDGen(vg);
	}
	return 0;
}
#endif

